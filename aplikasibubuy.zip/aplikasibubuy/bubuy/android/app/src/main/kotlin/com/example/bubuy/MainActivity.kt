package com.example.bubuy

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
