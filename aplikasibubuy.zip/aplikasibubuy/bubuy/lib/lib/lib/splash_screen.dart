// lib/splash_screen.dart

import 'package:flutter/material.dart';
import 'dart:async';

// Ini adalah contoh layar utama yang akan muncul setelah splash screen.
// Ganti ini dengan widget layar utama aplikasi Anda yang sebenarnya.
class MainScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Berita Burung Terbaru'),
        backgroundColor: Colors.blueAccent,
      ),
      body: Center(
        child: Text('Konten utama aplikasi Bubuy Lovers'),
      ),
    );
  }
}

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    // Gunakan Timer untuk menunda transisi ke layar utama
    Timer(Duration(seconds: 3), () { // Splash screen akan terlihat selama 3 detik
      // Navigasi ke MainScreen dan hapus SplashScreen dari stack navigasi
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => MainScreen()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Atur latar belakang menjadi hitam seperti gambar bubuy.png yang kamu berikan
      backgroundColor: Colors.black,
      body: Center(
        child: Image.asset(
          'assets/bubuy.png', // <-- Ini cara memanggil gambar kamu!
          width: 250, // Sesuaikan ukuran gambar sesuai kebutuhan
          height: 250,
          // Anda bisa menambahkan fit: BoxFit.contain untuk memastikan gambar pas dalam ukuran yang ditentukan
          fit: BoxFit.contain,
        ),
      ),
    );
  }
}